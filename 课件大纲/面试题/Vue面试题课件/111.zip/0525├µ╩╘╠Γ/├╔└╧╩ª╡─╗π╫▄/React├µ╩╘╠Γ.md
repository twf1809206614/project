# React面试题

### 1：hook解决了啥问题

### 2：react新特性

### 3：